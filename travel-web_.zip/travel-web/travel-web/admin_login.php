<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Example static admin (isse apna ID & pass daal de)
    if ($username === "admin" && $password === "1234") {
        $_SESSION['admin'] = $username;
        header("Location: admin_dashboard.php");
        exit();
    } else {
        $error = "Invalid ID or Password";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Admin Login</title>
  <style>
    body {
      background: #f9f9f9;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      font-family: sans-serif;
    }
    .top-bar {
      position: absolute;
      top: 1rem;
      right: 2rem;
    }
    .home-btn {
      padding: 0.5rem 1rem;
      border-radius: 0.5rem;
      background: #ddffdd;
      color: green;
      border: 0.2rem solid green;
      font-size: 1.6rem;
      text-decoration: none;
    }
    .admin-login {
      background: #fff;
      padding: 3rem 4rem;
      box-shadow: 0 0.3rem 0.5rem rgba(0,0,0,0.3);
      border-radius: 0.5rem;
      width: 35rem;
    }
    .admin-login h2 {
      text-align: center;
      color: #FF385C;
      margin-bottom: 2rem;
    }
    .admin-login form input {
      width: 100%;
      padding: 1rem;
      margin: 1rem 0;
      font-size: 1.6rem;
      border: 0.2rem solid #FF385C;
      border-radius: 0.5rem;
      outline: none;
    }
    .admin-login form input[type="submit"] {
      background: #FF385C;
      color: #fff;
      border: none;
      cursor: pointer;
      transition: 0.2s;
    }
    .admin-login form input[type="submit"]:hover {
      background: none;
      color: #FF385C;
      border: 0.2rem solid #FF385C;
    }
    .error {
      color: red;
      text-align: center;
      font-size: 1.4rem;
    }
    .team-boxes {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  position: absolute;
  top: 8rem; /* Navbar ke just niche */
  left: 2rem;
  z-index: 10;
}
</style>
</head>
<body>

  <div class="top-bar">
    <a href="index.html" class="home-btn">Home</a>
  </div>
  <div class="admin-login">
    <h2>Admin Login</h2>
    <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
    <form method="POST">
      <input type="text" name="username" placeholder="Admin ID" required>
      <input type="password" name="password" placeholder="Password" required>
      <input type="submit" value="Login">
    </form>
  </div>

</body>
</html>
