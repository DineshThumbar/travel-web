-- Create database
CREATE DATABASE IF NOT EXISTS travel_db;
USE travel_db;

-- Drop tables if exist to avoid duplicates
DROP TABLE IF EXISTS destinations;
DROP TABLE IF EXISTS events;
DROP TABLE IF EXISTS newsletter;
DROP TABLE IF EXISTS admin;

-- Create destinations table
CREATE TABLE destinations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  place VARCHAR(100),
  guests INT,
  arrival DATE,
  leaving DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO destinations (place, guests, arrival, leaving) VALUES
('Goa', 4, '2025-05-10', '2025-05-15'),
('Shimla', 2, '2025-06-01', '2025-06-05'),
('Kerala', 6, '2025-04-12', '2025-04-18'),
('Manali', 3, '2025-06-05', '2025-06-12'),
('Jaipur', 5, '2025-05-20', '2025-05-25'),
('Agra', 2, '2025-06-01', '2025-06-04');

CREATE TABLE events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  place VARCHAR(100),
  guests INT,
  event_name VARCHAR(100),
  event_date DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO events (place, guests, event_name, event_date) VALUES
('Delhi', 100, 'Wedding', '2025-05-20'),
('Mumbai', 50, 'Corporate Meet', '2025-04-30'),
('Chandigarh', 200, 'Concert', '2025-06-15'),
('Lucknow', 150, 'Exhibition', '2025-05-25'),
('Hyderabad', 80, 'Birthday Party', '2025-06-10'),
('Pune', 60, 'Seminar', '2025-06-05');

CREATE TABLE newsletter (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(150),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO newsletter (email) VALUES
('naturesimpleboy@example.com'),
('raghu32@example.com'),
('ram2633@example.com'),
('hippo123@example.com'),
('satya142@example.com');

CREATE TABLE admin (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50),
  password VARCHAR(255) -- store hashed password ideally
);

INSERT INTO admin (username, password) VALUES
('ADMIN', '1234');
