<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

// DB connection
$conn = new mysqli("localhost", "root", "", "travel_db");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query destinations
$query_dest = "SELECT * FROM destinations";
$result_dest = $conn->query($query_dest);
if (!$result_dest) {
    die("Destinations query failed: " . $conn->error);
}

// Query events
$query_events = "SELECT * FROM events";
$result_events = $conn->query($query_events);
if (!$result_events) {
    die("Events query failed: " . $conn->error);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        table { border-collapse: collapse; width: 80%; margin: 20px auto; }
        th, td { border: 1px solid #333; padding: 10px; text-align: center; }
        th { background: #FF385C; color: #fff; }
        .btn { display: inline-block; padding: 0.5rem 1rem; border: 2px solid; border-radius: 0.5rem; text-decoration: none; }
        .btn-home { color: green; border-color: green; float: right; margin: 10px; }
        .btn-logout { color: red; border-color: red; float: left; margin: 10px; }
    </style>
</head>
<body>
    <a href="index.html" class="btn btn-home">Home</a>
    <a href="logout.php" class="btn btn-logout">Logout</a>

    <h1 style="text-align:center;">Welcome to Admin Dashboard</h1>

    <h2 style="text-align:center;">Destinations</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Place</th>
            <th>Guests</th>
            <th>Arrival</th>
            <th>Leaving</th>
            <th>Created At</th>
        </tr>
        <?php while($row = $result_dest->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['id']; ?></td>
            <td><?= $row['place']; ?></td>
            <td><?= $row['guests']; ?></td>
            <td><?= $row['arrival']; ?></td>
            <td><?= $row['leaving']; ?></td>
            <td><?= $row['created_at']; ?></td>
        </tr>
        <?php } ?>
    </table>

    <h2 style="text-align:center;">Events</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Place</th>
            <th>Guests</th>
            <th>Event Name</th>
            <th>Event Date</th>
            <th>Created At</th>
        </tr>
        <?php while($row = $result_events->fetch_assoc()) { ?>
        <tr>
            <td><?= $row['id']; ?></td>
            <td><?= $row['place']; ?></td>
            <td><?= $row['guests']; ?></td>
            <td><?= $row['event_name']; ?></td>
            <td><?= $row['event_date']; ?></td>
            <td><?= $row['created_at']; ?></td>
        </tr>
        <?php } ?>
    </table>
</body>
</html>
