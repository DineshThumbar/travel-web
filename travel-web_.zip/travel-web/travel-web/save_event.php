<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $place = $_POST['eventPlace'];
  $guests = $_POST['eventGuests'];
  $name = $_POST['eventName'];
  $date = $_POST['eventDate'];

  $sql = "INSERT INTO events (eventPlace, eventGuests, eventName, eventDate) VALUES ('$place', $guests, '$name', '$date')";
  if ($conn->query($sql) === TRUE) {
    echo "<h2>Event saved successfully!</h2><a href='index.html'>Go Back</a>";
  } else {
    echo "Error: " . $conn->error;
  }
}
?>
