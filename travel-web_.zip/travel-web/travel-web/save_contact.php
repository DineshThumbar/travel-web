<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $message = $_POST['message'];

  $sql = "INSERT INTO contacts (name, email, message) VALUES ('$name', '$email', '$message')";
  if ($conn->query($sql) === TRUE) {
    echo "<h2>Contact saved successfully!</h2><a href='contact.html'>Go Back</a>";
  } else {
    echo "Error: " . $conn->error;
  }
}
?>
