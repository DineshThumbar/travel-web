<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $email = $_POST['email'];

  $sql = "INSERT INTO newsletter (email) VALUES ('$email')";
  if ($conn->query($sql) === TRUE) {
    echo "success";
  } else {
    echo "error";
  }
}
?> 