<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $place = $_POST['place'];
  $guests = $_POST['guests'];
  $arrival = $_POST['arrival'];
  $leaving = $_POST['leaving'];

  $sql = "INSERT INTO destinations (place, guests, arrival, leaving) VALUES ('$place', $guests, '$arrival', '$leaving')";
  if ($conn->query($sql) === TRUE) {
    echo "<h2>Destination saved successfully!</h2><a href='index.html'>Go Back</a>";
  } else {
    echo "Error: " . $conn->error;
  }
}
?>
