<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $email = $_POST['email'];

  $sql = "INSERT INTO newsletter (email) VALUES ('$email')";
  if ($conn->query($sql) === TRUE) {
    echo "
    <!DOCTYPE html>
    <html lang='en'>
    <head>
      <meta charset='UTF-8'>
      <title>Signup Success</title>
      <link rel='stylesheet' href='style.css'>
      <style>
      .thank-you-container {
  max-width: 600px;
  margin: 100px auto;
  padding: 30px;
  text-align: center;
  background: #fff;
  border-radius: 1rem;
  box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
  animation: fadeIn 0.5s ease-in-out;
}

.thank-you-container h1 {
  font-size: 3rem;
  color: #28a745; /* Green for success */
  margin-bottom: 1rem;
}

.thank-you-container p {
  font-size: 1.8rem;
  color: #555;
  margin-bottom: 2rem;
}

.thank-you-container .highlight {
  font-weight: bold;
  color: #FF385C;
}

.go-back-btn {
  display: inline-block;
  padding: 1rem 2rem;
  font-size: 1.6rem;
  background-color: #FF385C;
  color: #fff;
  text-decoration: none;
  border-radius: 0.5rem;
  transition: background 0.3s ease;
}

.go-back-btn:hover {
  background-color: #e62e50;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(-20px); }
  to { opacity: 1; transform: translateY(0); }
}

/* Error style */
.thank-you-container h1:contains('Oops!') {
  color: #dc3545; /* Red for error */
}

      </style>
    </head>
    <body>
      <div class='thank-you-container'>
        <h1>🎉 Congratulations! 🎉</h1>
        <p>Thank you for signing up! <span class='highlight'>25% discount</span> applied. 🏖️</p>
        <a href='index.html' class='go-back-btn'>← Go Back</a>
      </div>
    </body>
    </html>
    ";
  } else {
    echo "
    <!DOCTYPE html>
    <html lang='en'>
    <head>
      <meta charset='UTF-8'>
      <title>Error</title>
      <link rel='stylesheet' href='style.css'>
    </head>
    <body>
      <div class='thank-you-container'>
        <h1>❌ Oops!</h1>
        <p>Something went wrong. Please try again. 😔</p>
        <a href='index.html' class='go-back-btn'>← Go Back</a>
      </div>
    </body>
    </html>
    ";
  }
}
?>
